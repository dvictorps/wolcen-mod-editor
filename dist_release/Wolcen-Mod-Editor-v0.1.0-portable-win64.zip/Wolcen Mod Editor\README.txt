﻿Wolcen Mod Editor (portable)

1. Run "Wolcen Mod Editor.exe".
2. On first run, point it at your Wolcen install folder
   (the one containing Game\Umbra.pak). It decrypts what it needs once.
3. Edit skills / passives / player stats, name your mod, click Export.
4. Copy the exported "Umbra" folder into <Wolcen>\Game\ and launch the game.

Keep the "tools" folder next to the exe (bundled decryptors).
If decryption fails, install "Microsoft Visual C++ 2015-2019 Redistributable (x86)".
You need your own copy of Wolcen. Mods are offline-only.

Source & updates: https://github.com/dvictorps/wolcen-mod-editor
